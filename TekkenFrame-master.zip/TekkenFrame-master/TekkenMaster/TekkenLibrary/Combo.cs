﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TekkenLibrary
{
	public class Combo
	{
		public List<Command> StringMoves { get; set; }
	}
}

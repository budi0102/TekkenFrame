﻿namespace TekkenDB.Enums
{
    public enum Locale
    {
        English,
        Japanese
    }
}

﻿using System;

namespace TekkenDB.Enums
{
    public enum DamageScaling
    {
        None = 0,
        Normal135,
        Normal60,
        Normal50

    }
}
